import pygame # Importer un module 
import math
from game import Game
from player import Player
pygame.init() # Charger les composants qui sont à l'intérieur


#def clock
clock = pygame.time.Clock()
FPS = 60


# Generer la fenêtre du jeu
pygame.display.set_caption("Comet fall Game") # Définir le titre de la fenêtre
screen = pygame.display.set_mode((1080, 720)) # Dimension de la fenêtre HauteurxLargeur

# Charger l'arriere plan du jeu
background = pygame.image.load('assets/bg.jpg')

# Charger notre bannière
banner = pygame.image.load('assets/banner.png')
banner = pygame.transform.scale(banner, (500, 500))
banner_rect = banner.get_rect()
banner_rect.x = math.ceil(screen.get_width() / 4)

# Import button Start
play_button = pygame.image.load('assets/button.png')
play_button = pygame.transform.scale(play_button, (400, 150))
play_button_rect = play_button.get_rect()
play_button_rect.x = math.ceil(screen.get_width() / 3.33)
play_button_rect.y = math.ceil(screen.get_height() / 2)
# Loading the game
game = Game()


running = True # fenêtre en cour d'execution
is_jump = False


while running:

    # Appliquer le background 
    screen.blit(background,(0, -200))

    # Vérification si le jeu à commencer
    if game.is_playing:
        # Déclencher les instructions de la partie
        game.update(screen)
    #verif si le jeu n'a pas commence
    else:
        # Ajouter l'écran de bienvenue
        screen.blit(play_button, play_button_rect)
        screen.blit(banner, banner_rect)


    # Mettre à jour l'écran
    pygame.display.flip()

    # Condition sortie (fermeture de la fenêtre)
    for event in pygame.event.get():        
        if event.type == pygame.QUIT:
            running = False # Stop la boucle
            pygame.quit() # Quitter l'application de notre jeu

        # Détecter si un joueur lache une touche du clavier
        elif event.type == pygame.KEYDOWN:
            game.pressed[event.key] = True

            # Détecter si la touche esp est déclenchée pour lancer notre projectile.
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:                
                if not game.is_playing:
                    # lancer le jeu
                    game.start()

            #detect la touche space pour tiré
            if event.key == pygame.K_s:
                game.player.launch_projectile()

        elif event.type == pygame.KEYUP:
            game.pressed[event.key] = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            #verif pour savoir si la souris est en collision avec le boutton jouer
            if play_button_rect.collidepoint(event.pos):
                # Lancer le jeu
                game.start()
                # Jouer le son
                game.sound_manager.play('click')

    # fixer le nbr de fPS
    clock.tick(FPS)
